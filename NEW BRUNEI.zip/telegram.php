<?php
$telegram_id = "1800983";
$id_bot = "69582hniZGW8nSqMpLoE198A";
?>
